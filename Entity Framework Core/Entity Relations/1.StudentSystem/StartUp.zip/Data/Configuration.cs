﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    public static class Configuration
    {
        public const string CONNECTION_STRING = @"Server=.;Database=Students;User=sa;Password=Maxmen111;";
    }
}
