﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTO.Product
{
    public class ProductNamePriceViewDto
    {
        public string Name { get; set; }

        public decimal Price { get; set; }
    }
}
