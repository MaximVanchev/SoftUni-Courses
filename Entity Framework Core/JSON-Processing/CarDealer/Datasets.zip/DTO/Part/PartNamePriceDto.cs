﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO.Part
{
    public class PartNamePriceDto
    {
        public string Name { get; set; }

        public decimal Price { get; set; }
    }
}
