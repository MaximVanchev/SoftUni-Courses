﻿using CarDealer.DTO.Part;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO.Car
{
    public class CarWithPartsDto
    {
        public string Make { get; set; }

        public string Model { get; set; }

        public long TravelledDistance { get; set; }

        public ICollection<PartNamePriceDto> parts { get; set; } = new List<PartNamePriceDto>();
    }
}
