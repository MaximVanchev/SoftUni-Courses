﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO.Car
{
    public class CarListDto
    {
        public ICollection<CarWithPartsDto> cars { get; set; }
    }
}
