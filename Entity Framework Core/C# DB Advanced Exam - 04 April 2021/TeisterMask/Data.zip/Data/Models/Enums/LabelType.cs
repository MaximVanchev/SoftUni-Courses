﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeisterMask.Data.Models.Enums
{
    public enum LabelType
    {
        Priority, 
        CSharpAdvanced, 
        JavaAdvanced, 
        EntityFramework, 
        Hibernate
    }
}
