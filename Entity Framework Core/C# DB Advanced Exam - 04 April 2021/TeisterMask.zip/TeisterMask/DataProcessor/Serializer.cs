﻿namespace TeisterMask.DataProcessor
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using Data;
    using Microsoft.EntityFrameworkCore;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Serialization;
    using TeisterMask.Data.Models;
    using TeisterMask.DataProcessor.ExportDto;
    using Formatting = Newtonsoft.Json.Formatting;

    public class Serializer
    {
        public static string ExportProjectWithTheirTasks(TeisterMaskContext context)
        {
            throw new NotImplementedException();
        }

        public static string ExportMostBusiestEmployees(TeisterMaskContext context, DateTime date)
        {
            IMapper mapper = InitializeMapper();

            List<Employee> employees = context.Employees.Include(e => e.EmployeesTasks).ThenInclude(et => et.Task)
                .Where(e => e.EmployeesTasks.Any(et => et.Task.OpenDate >= date))
                .Where(e => e.EmployeesTasks.Count > 0).ToList();

            List<EmployeeExportDto> employeeExportDtos = mapper
                .Map<ICollection<Employee>,ICollection<EmployeeExportDto>>(employees).ToList();

            for (int i = 0; i < employees.Count; i++)
            {
                List<TaskExportDto> taskExportDtos = mapper.Map<ICollection<Task>, ICollection<TaskExportDto>>
                    (employees[i].EmployeesTasks.Select(e => e.Task).ToList()).ToList();

                employeeExportDtos[i].Tasks = taskExportDtos;
            }

            string resultJson = JsonConvert.SerializeObject(employeeExportDtos, JsonSettings());

            return resultJson;
        }

        private static JsonSerializerSettings JsonSettings()
        {
            DefaultContractResolver defaultContractResolver = new DefaultContractResolver()
            {
                NamingStrategy = new CamelCaseNamingStrategy()
            };

            JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings()
            {
                Formatting = Formatting.Indented,
                ContractResolver = defaultContractResolver
            };

            return jsonSerializerSettings;
        }

        private static IMapper InitializeMapper()
        {
            IConfigurationProvider configuration = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<TeisterMaskProfile>();
            });

            IMapper mapper = new Mapper(configuration);
            return mapper;
        }
    }
}