﻿using System;
using TeisterMask.Data.Models.Enums;

namespace TeisterMask.DataProcessor.ExportDto
{
    public class TaskExportDto
    {
        public string TaskName { get; set; }

        public DateTime OpenDate { get; set; }

        public DateTime DueDate { get; set; }

        public LabelType LabelType { get; set; }

        public ExecutionType ExecutionType { get; set; }
    }
}
