﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeisterMask.Data.Models.Enums
{
    public enum ExecutionType
    {
        ProductBacklog = 2, 
        SprintBacklog = 4, 
        InProgress = 6, 
        Finished = 8
    }
}
