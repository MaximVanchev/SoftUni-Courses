﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeisterMask.Data.Models.Enums
{
    public enum LabelType
    {
        Priority = 2, 
        CSharpAdvanced = 4, 
        JavaAdvanced = 6, 
        EntityFramework = 8, 
        Hibernate = 10
    }
}
