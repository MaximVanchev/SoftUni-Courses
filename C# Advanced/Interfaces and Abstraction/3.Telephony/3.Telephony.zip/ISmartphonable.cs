﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface ISmartphonable
    {
        string CallOtherSmartPhones(string number);
        string BrowseInTheWorldWideWeb(string web);
    }
}
