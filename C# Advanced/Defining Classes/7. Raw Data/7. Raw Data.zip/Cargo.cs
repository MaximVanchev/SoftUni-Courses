﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _7._Raw_Data
{
    public class Cargo
    {
        public double Weight { get; set; }
        public string Type { get; set; }
    }
}
