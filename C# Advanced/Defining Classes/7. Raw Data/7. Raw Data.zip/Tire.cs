﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _7._Raw_Data
{
    public class Tire
    {
        public double Tire1Pressure { get; set; }
        public double Tire1Age { get; set; }
        public double Tire2Pressure { get; set; }
        public double Tire2Age { get; set; }
        public double Tire3Pressure { get; set; }
        public double Tire3Age { get; set; }
        public double Tire4Pressure { get; set; }
        public double Tire4Age { get; set; }
    }
}
